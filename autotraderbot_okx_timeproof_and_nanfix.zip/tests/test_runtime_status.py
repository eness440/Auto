"""
Unit tests for runtime_status.py
"""

from __future__ import annotations

import json
from pathlib import Path

from .. import runtime_status as rs


def test_update_status(tmp_path: Path) -> None:
    # Redirect runtime status files to temporary directory
    orig_status = rs.RUNTIME_STATUS_FILE
    orig_dash = rs.DASHBOARD_FILE
    try:
        rs.RUNTIME_STATUS_FILE = tmp_path / "runtime_status.json"
        rs.DASHBOARD_FILE = tmp_path / "dashboard.json"
        rs.update_status(open_trades=3, daily_pnl=10.0, kill_switch="OFF")
        # Both files should exist
        assert rs.RUNTIME_STATUS_FILE.exists()
        assert rs.DASHBOARD_FILE.exists()
        data = json.loads(rs.RUNTIME_STATUS_FILE.read_text(encoding="utf-8"))
        assert data["open_trades"] == 3
        assert data["daily_pnl"] == 10.0
        assert data["kill_switch"] == "OFF"
        # A timestamp should be present
        assert "last_update_ts" in data
    finally:
        # Restore original paths
        rs.RUNTIME_STATUS_FILE = orig_status
        rs.DASHBOARD_FILE = orig_dash
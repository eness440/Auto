"""
Unit tests for db_utils.py
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from ..db_utils import initialise_db, insert_trade, insert_metrics, insert_prediction


def test_db_operations(tmp_path: Path) -> None:
    # Create a temporary database
    db_file = tmp_path / "test.db"
    initialise_db(db_file)
    conn = sqlite3.connect(db_file)
    try:
        # Insert a trade
        trade = {
            "symbol": "BTCUSDT",
            "side": "long",
            "entry_price": 100.0,
            "exit_price": 110.0,
            "size": 1.0,
            "pnl_usd": 10.0,
            "pnl_pct": 10.0,
            "timestamp_open": "2025-01-01T00:00:00",
            "timestamp_close": "2025-01-01T01:00:00",
        }
        insert_trade(conn, trade)
        # Insert metrics
        metrics = {
            "timestamp": "2025-01-01T00:00:00",
            "api_calls": 3,
            "api_errors": 1,
            "api_retries": 0,
            "total_latency": 0.5,
            "realized_pnl": 5.0,
            "unrealized_pnl": 0.0,
            "exposure_usd": 100.0,
            "expectancy": 0.1,
            "trade_count": 1,
        }
        insert_metrics(conn, metrics)
        # Insert prediction
        pred = {
            "symbol": "BTCUSDT",
            "timestamp": "2025-01-01T00:00:00",
            "ai_confidence": 0.8,
            "tech_score": 0.5,
            "sent_score": 0.1,
            "master_confidence": 0.7,
            "provider": "ChatGPT",
        }
        insert_prediction(conn, pred)
        conn.commit()
        c = conn.cursor()
        # Check counts
        trades_count = c.execute("SELECT COUNT(*) FROM trades").fetchone()[0]
        metrics_count = c.execute("SELECT COUNT(*) FROM metrics").fetchone()[0]
        preds_count = c.execute("SELECT COUNT(*) FROM predictions").fetchone()[0]
        assert trades_count == 1
        assert metrics_count == 1
        assert preds_count == 1
    finally:
        conn.close()
"""
Unit tests for metrics_manager.py
"""

from __future__ import annotations

import json
from pathlib import Path

from .. import metrics_manager as mm


def test_write_metrics(tmp_path: Path) -> None:
    # Backup original metrics file path
    orig_file = mm.METRICS_FILE
    try:
        # Redirect metrics file to a temporary location
        tmp_metrics = tmp_path / "metrics.json"
        mm.METRICS_FILE = tmp_metrics
        # Set some metrics and write
        mm._metrics["api_calls"] = 5
        mm._metrics["api_errors"] = 1
        mm._metrics["last_updated"] = "2020-01-01T00:00:00"
        mm._write_metrics()
        assert tmp_metrics.exists()
        data = json.loads(tmp_metrics.read_text(encoding="utf-8"))
        assert data["api_calls"] == 5
        assert data["api_errors"] == 1
    finally:
        # Restore original path
        mm.METRICS_FILE = orig_file
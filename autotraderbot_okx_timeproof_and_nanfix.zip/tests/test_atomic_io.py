"""
Unit tests for atomic_io.py
"""

from __future__ import annotations

import json
from pathlib import Path

from ..atomic_io import safe_write_json


def test_safe_write_json(tmp_path: Path) -> None:
    # Write a simple dictionary and verify it is persisted correctly
    p = tmp_path / "simple.json"
    data = {"hello": "world", "n": 42}
    safe_write_json(p, data)
    assert p.exists()
    loaded = json.loads(p.read_text(encoding="utf-8"))
    assert loaded == data

    # Overwrite the same file
    data2 = {"foo": "bar"}
    safe_write_json(p, data2)
    loaded2 = json.loads(p.read_text(encoding="utf-8"))
    assert loaded2 == data2
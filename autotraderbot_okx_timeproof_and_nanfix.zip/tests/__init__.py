"""
Test package for AutoTraderBot.

To run tests install pytest and execute::

    pytest -q

This package contains basic unit tests for core utilities such as
atomic writes, metrics manager and runtime status.  Additional tests
should be added to improve coverage and regression detection.
"""